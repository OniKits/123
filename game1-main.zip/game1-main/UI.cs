using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class UI : MonoBehaviour
{
    [SerializeField] private manager Manager;
    [SerializeField] private Text questionText;
    [SerializeField] private Text scoreText;
    [SerializeField] private Text timerText;
    [SerializeField] private List<Image> lifeImageList;
    [SerializeField] private GameObject _gameOverPanel;
    [SerializeField] private GameObject _mainMenuPanel;
    [SerializeField] private GameObject _gameMenuPanel;
    [SerializeField] private Image questionImage;
    [SerializeField] private UnityEngine.Video.VideoPlayer questionVideo;
    [SerializeField] private AudioSource questionAudio;
    [SerializeField] public List<Button> options;
    [SerializeField] public List<Button> UIbuttons;
    [SerializeField] private Color correctCol, WrongCol,NormalCOL;
    public GameObject kawaii;

    private Question question;
    private bool ansewresd;
    private float audioLength;

    public Text ScoreText { get { return scoreText; } }
    public Text TimerText { get { return timerText; } }
    public GameObject GameOverPanel { get { return _gameOverPanel; } }

    void Awake()
    {
        for (int i = 0; i < options.Count; i++)
        {
            Button localbtn = options[i];
            localbtn.onClick.AddListener(() => OnClick(localbtn));
        }

        for (int i = 0; i < UIbuttons.Count; i++)
        {
            Button localbtn = UIbuttons[i];
            localbtn.onClick.AddListener(() => OnClick(localbtn));
        }
    }

    public void SetQuestion(Question question)
    {
        this.question = question;

        switch(question.questionType)
        {
            case QuestionType.TEXT:
                questionImage.transform.parent.gameObject.SetActive(true);
                kawaii.SetActive(false);
                break;
            case QuestionType.IMAGE:
                kawaii.SetActive(true);
                ImageHolder();
                questionImage.transform.gameObject.SetActive(true);
                questionImage.sprite = question.questionImg;
                break;
            case QuestionType.VIDEO:
                kawaii.SetActive(true);
                ImageHolder();
                questionVideo.transform.gameObject.SetActive(true);
                questionVideo.clip = question.questionVideo;
                questionVideo.Play();
                break;
            case QuestionType.AUDIO:
                kawaii.SetActive(true);
                ImageHolder();
                questionAudio.transform.gameObject.SetActive(true);
                audioLength = question.questionClip.length;
                StartCoroutine(PlayAudio());
                break;
        }

        questionText.text = question.questionInfo;
        List<string> answerList = ShuffleList.ShuffleListItems<string>(question.options);

        for (int i = 0; i < options.Count; i++)
        {
            options[i].GetComponentInChildren<Text>().text = answerList[i];
            options[i].name = answerList[i];
            options[i].image.color = NormalCOL;
        }

        ansewresd = false;
    }

    IEnumerator PlayAudio()
    {
        if (question.questionType == QuestionType.AUDIO)
        {
            questionAudio.PlayOneShot(question.questionClip);

            yield return new WaitForSeconds(audioLength + 0.5f);

            StartCoroutine(PlayAudio());
        }
        else
        {
            StopCoroutine(PlayAudio());
            yield return null;
        }
    }

    void ImageHolder()
    {
        questionImage.transform.parent.gameObject.SetActive(true);
        questionImage.transform.gameObject.SetActive(false);
        questionAudio.transform.gameObject.SetActive(false);
        questionVideo.transform.gameObject.SetActive(false);
    }

    private void OnClick(Button btn)
    {
        if (Manager.GameStatus == GameStatus.Plaing)
        {
            if (!ansewresd)
            {
                ansewresd = true;
                bool val = Manager.Answer(btn.name);
                if (val)
                {
                    btn.image.color = correctCol;
                }
                else
                {
                    btn.image.color = WrongCol;
                }
            }
        }
        switch (btn.name)
        {
            case "easy":
                Manager.StartGame(0);
                _mainMenuPanel.SetActive(false);
                _gameMenuPanel.SetActive(true);
                break;
            case "medium":
                Manager.StartGame(1);
                _mainMenuPanel.SetActive(false);
                _gameMenuPanel.SetActive(true);
                break;
            case "hard":
                Manager.StartGame(2);
                _mainMenuPanel.SetActive(false);
                _gameMenuPanel.SetActive(true);
                break;
        }
    }

    public void RetryButton()
    {
        SceneManager.LoadScene(1);
    }

    public void ReduceLife(int index)
    {
        lifeImageList[index].color = WrongCol;
    }
}
