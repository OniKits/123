using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class sounds : MonoBehaviour
{
    public AudioSource click;

    private void Update()
    {
        if (Input.GetButtonDown("Fire1"))
        {
            click.Play();
        }
    }
}
