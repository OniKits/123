using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class size : MonoBehaviour
{
    void Start()
    {
        Screen.SetResolution(2560, 1980, true);
    }
}
