using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class ShuffleList
{
    public static List<E> ShuffleListItems<E>(List<E> inputList)
    {
        List<E> Root = new List<E>();
        Root.AddRange(inputList);
        List<E> randomList = new List<E>();

        System.Random num = new System.Random();
        int randind = 0;
        while (Root.Count > 0)
        {
            randind = num.Next(0, Root.Count);
            randomList.Add(Root[randind]);
            Root.RemoveAt(randind);
        }
        return randomList;
    }
}
