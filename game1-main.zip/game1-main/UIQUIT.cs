using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class UIQUIT : MonoBehaviour
{
    public void qiut()
    {
        Application.Quit();
    }

    public void ansc()
    {
        SceneManager.LoadScene(1);
    }
}
