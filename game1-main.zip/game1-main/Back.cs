using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Back : MonoBehaviour
{
    public GameObject plov;
    private bool sost = true;
    [SerializeField] private manager Manage;

    void Update()
    {
        if ((Input.GetKeyDown(KeyCode.Escape)) && (Manage.col == 0))
        {
            plov.SetActive(sost);
            sost = !sost;
        }
    }

}
