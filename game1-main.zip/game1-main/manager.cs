using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class manager : MonoBehaviour
{
    [SerializeField] private UI quiUi;
    private List<Question> questions;
    private Question selectedQuestion;
    [SerializeField] private List<Dtabaase> Basedata;
    [SerializeField] private float timelimit = 60;
    private int scoreCount = 0;
    private float curTime;
    private int lifeRemaining = 3;
    public int col = 0;

    public float TimeLimit { get { return timelimit; } }
    private GameStatus gameStatus = GameStatus.Next;
    public GameStatus GameStatus { get { return gameStatus; } }

    public void StartGame(int index)
    {
        scoreCount = 0;
        curTime = timelimit;
        lifeRemaining = 3;
        questions = new List<Question>();
        for (int i = 0; i
                        < Basedata[index].questions.Count; i++)
        {
            questions.Add(Basedata[index].questions[i]);
        }
        SelectQuestion();
        gameStatus = GameStatus.Plaing;
        col = 0;
    }

    private void SelectQuestion()
    {
        int val = UnityEngine.Random.Range(0, questions.Count);
        selectedQuestion = questions[val];
        quiUi.SetQuestion(selectedQuestion);

        questions.RemoveAt(val);
    }

    private void Update()
    {
        if (gameStatus == GameStatus.Plaing)
        {
            curTime -= Time.deltaTime;
            SetTimer(curTime);
            col = 1;
        }
        else
        {
            col = 0;
        }
    }
    private void SetTimer(float value)
    {
        TimeSpan time = TimeSpan.FromSeconds(value);
        quiUi.TimerText.text = "�����:" + time.Seconds;

        if (curTime <= 0)
        {
            gameStatus = GameStatus.Next;
            quiUi.GameOverPanel.SetActive(true);
        }
    }

    public bool Answer(string answered)
    {
        bool correctans = false;

        if (answered == selectedQuestion.correctAns)
        {
            correctans = true;
            scoreCount += 50;
            quiUi.ScoreText.text = "����:" + scoreCount;
        }
        else
        {
            lifeRemaining--;
            quiUi.ReduceLife(lifeRemaining);

            if (lifeRemaining <= 0)
            {
                gameStatus = GameStatus.Next;
                quiUi.GameOverPanel.SetActive(true);
            }
        }

        if (gameStatus == GameStatus.Plaing)
        {
            if (questions.Count > 0)
            {
                Invoke("SelectQuestion", 0.4f);
            }
            else
            {
                gameStatus = GameStatus.Next;
                quiUi.GameOverPanel.SetActive(true);
            }
        }
        return correctans;
    }
}

[System.Serializable]
public class Question
{
    public string questionInfo;
    public QuestionType questionType;
    public Sprite questionImg;
    public UnityEngine.Video.VideoClip questionVideo;
    public AudioClip questionClip;
    public List<string> options;
    public string correctAns;
}


[System.Serializable]
public enum QuestionType
{
    TEXT,
    IMAGE,
    VIDEO,
    AUDIO
}

[System.Serializable]
public enum GameStatus
{
    Next,
    Plaing
}